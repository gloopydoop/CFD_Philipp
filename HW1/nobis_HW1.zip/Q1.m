Pe = 300;
Pc0 = 10;
R = 5;
T = 1;
v = 2.5;
P = (Pe-Pc0)/(R*T)*(T/2 - T)*v*T/2 + Pe
100/P